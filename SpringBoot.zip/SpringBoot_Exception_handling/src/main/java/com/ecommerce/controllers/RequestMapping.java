package com.ecommerce.controllers;

public @interface RequestMapping {

}
